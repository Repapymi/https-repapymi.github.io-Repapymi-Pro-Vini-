document.addEventListener("DOMContentLoaded", function () {
    var meuTexto = document.getElementById("meuTexto");
    meuTexto.innerHTML = "Se a beleza fosse tempo, você seria a eternidade."
    "Você não é um dicionário, mas é a definição do meu amor."
    "Seu sorriso deve ser uma constelação, porque ilumina o meu mundo."
    "Se beleza desse cadeia, você pegaria prisão perpétua."
    "Você não é Google, mas tem tudo o que tenho pesquisado."
    "Aposto um beijo que você me dá um fora."
    "Você é a resposta para todas as minhas preces."
    "Eu não sou fotógrafo, mas posso facilmente imaginar nós dois juntos."
    "Você não é um ladrão, mas você roubou meu coração."
    "Se beijos fossem flores, eu te daria um jardim.";
    alert("De Joel para Vini");
});